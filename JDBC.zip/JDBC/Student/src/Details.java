
import java.sql.*;

import java.util.*;

public class Details{

 public static void main(String[] args) {

   Connection con;

   Statement st;

   ResultSet rs;

   int num =0,age=0,ch=0,i=0;
   
   String nam;

   Scanner sc=new Scanner(System.in);

   try {

   Class.forName("com.mysql.jdbc.Driver");

   }

   catch(Exception e) {

        System.out.println("Connection Error");

   }
   
   //do-while loop

   do {

   System.out.println("\t\t1.Create");

   System.out.println("\t\t2.Add");

   System.out.println("\t\t3.Modify");

   System.out.println("\t\t4.Display");

   System.out.println("\t\t5.Delete");

   System.out.println("\t\t6.Exit");

   System.out.println("\t\t\nEnter your code");

     ch=sc.nextInt();
     
     
     /* ********************************************************************* Switch case ******************************************************************************************/  

   switch(ch)

   {

   case 1:

   System.out.println("Table creation");

    try {

       con=DriverManager.getConnection("jdbc:mysql://localhost:3309/Student","root","dbms");

       st=con.createStatement();

       i=st.executeUpdate("create table fresher(ecode int primary key,name varchar(50),age int)");

    System.out.println("\t\tTable created");

    st.close();

    con.close();

    }

    catch(Exception e) {

    System.out.println("Table Creation failed");

    }

    break;

    /* *****************************************************************************************************************************************************************************/  
    
   case 2:

	   System.out.println("Add Record ");

	   System.out.println("Enter emp no :");
	   
	   num=sc.nextInt();
	   
	   System.out.println("Enter emp name :");

	   nam=sc.next();

	   System.out.println("Enter Age :");

	   age =sc.nextInt();

	    try {

	       con=DriverManager.getConnection("jdbc:mysql://localhost:3309/Student","root","dbms");

	       st=con.createStatement();

	       i=st.executeUpdate("insert into fresher values("+num+",'"+nam+"',"+age+")");

	    System.out.println("\t\tRecord Added");

	    st.close();

	    con.close();

	    }

	    catch(Exception e) {

	    System.out.println("Add Record error");

	    }

	    break;
	    
	/* *****************************************************************************************************************************************************************************/    
  
    case 4:
	   
	   try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3309/Student", "root", "dbms");
			
			st=con.createStatement();
			
			rs=st.executeQuery("select * from fresher");
			
			int j=1;
			
			while(rs.next()) {
				
				System.out.println(j + " Ecode : " + rs.getInt(1) + "  Ename : " + rs.getString(2) + "  Age : " + rs.getInt(3));
				
				j++;
			}
			
			st.close();
			
			con.close();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			
		}
	   
	   break;
	  
	   /* *****************************************************************************************************************************************************************************/  
	    
   case 5:

	   System.out.println("Delete Record ");

	   System.out.println("Enter emp no :");
	   
	   num=sc.nextInt();

	    try {

	       con=DriverManager.getConnection("jdbc:mysql://localhost:3309/Student","root","dbms");

	       st=con.createStatement();

	       i=st.executeUpdate("delete from fresher where ecode="+num);

	    System.out.println("\t\tRecord deleted");

	    st.close();

	    con.close();
	    
	    }
	    catch (SQLException e) {
	    	
			e.printStackTrace();
		}
	   break;
	   
	   /* *****************************************************************************************************************************************************************************/  

   case 3:

	   System.out.println("modify Record :");

	   System.out.println("Enter emp no :");

	   num=sc.nextInt();

	   System.out.println("Enter emp name :");

	   nam=sc.next();

	   System.out.println("Enter Age :");

	   age =sc.nextInt();

	    try {

	       con=DriverManager.getConnection("jdbc:mysql://localhost:3309/Student","root","dbms");

	       st=con.createStatement();

	       i=st.executeUpdate("update fresher set name='"+nam+"',age="+age+" where ecode="+num);

	    System.out.println("\t\tRecord Added");

	    st.close();

	    con.close();

	    }

	    catch(Exception e) {

	    System.out.println("Add Record error");

	    }

	    break;
	    
	    /* *****************************************************************************************************************************************************************************/  
	    
   case 6:

	   ch=7;
	   
	   /* *****************************************************************************************************************************************************************************/ 

	   }}

	   while(ch<6) ;

	   System.out.println("Exited...");
}

}

